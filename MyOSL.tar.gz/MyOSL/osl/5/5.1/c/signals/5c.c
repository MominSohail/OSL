/*
================================================================================================
 Name        	   : 5c.c
 Author      	   : Amar Chandole	
 Roll No.	 	   : 3807
 Problem Statement : Signals: Detecting the termination of multiple child processes-
							  Implement the C program to demonstrate the use of SIGCHLD
							  signal. A parent process Creates multiple child process (minimum
							  three child processes). Parent process should be Sleeping until it
							  creates the number of child processes. Child processes send
							  SIGCHLD signal to parent process to interrupt from the sleep and
							  force the parent to call wait for the Collection of status of
							  terminated child processes.		  	
================================================================================================
*/

#include <unistd.h>
#include <signal.h>
#include <sys/wait.h>
#include <stdio.h>

void handle_sigchld(intsig)
{
	pid_t pid;
	int status;

	while (1) 
	{
		pid = waitpid(-1, &status, WNOHANG);
		if (pid <= 0) 							// No more zombie children to reap.
			break;

		printf("Reaped child %d\n",pid);
	}
	sleep(1);
}

int main() 
{
	int i;
	signal(SIGCHLD,handle_sigchld);

	for (i= 0;i< 3;i++) 
	{
		if (fork() == 0) 						//Child-process code.
		{
			printf("Hello from child %d\n",getpid());
			sleep(5);
			return 0;
			//Terminate child
		}
	}	

	while (1)									//Parent-process code.
		sleep(2);								//Wait for children
		
	return 0;									//to terminate.
} 
