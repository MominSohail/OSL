//server

#include<stdio.h>
#include<stdlib.h>
#include<fcntl.h>           
#include<unistd.h>
#include<unistd.h>
#include<string.h>

int main()
{
	int i=0, num, fd1, fd2;
	char input[1000], output[1000], c;

	mkfifo("firstfifo", 0644);
	fd1 = open("firstfifo", O_WRONLY);
	fd2 = open("secondfifo", O_RDONLY);

	printf("\nSERVER : Ready to send!\n");
	while((c=getc(stdin))!='`')	
		input[i++] = c;
	input[i] = '\0';
	
	printf("\nSERVER : Input is \n%s", input);
	write(fd1, input, strlen(input));
		
	printf("\nSERVER : Sent");

	
	while((num=read(fd2, output, 1000))>0)			
	{
		output[num] = '\0';
		printf("\nRECIEVED:\n%s", output);
		fflush(stdout);
		break;
	}	

	return 0;
}

