//client

#include<stdio.h>
#include<stdlib.h>
#include<fcntl.h>           
#include<unistd.h>
#include<unistd.h>
#include<ctype.h>
#include<string.h>

int main()
{
	int i, fd1, fd2, n, c, chars=0, words=0, lines=0;
	char input[1000], output[1000]="", a[100];
	FILE* fp;
	
	mkfifo("secondfifo", 0644);
	fd1 = open("firstfifo", O_RDONLY);
	fd2 = open("secondfifo", O_WRONLY);

	while((n=read(fd1, input, 1000))>0)
	{	
		input[n]='\0';
		printf("\nThe contents recieved from FIFO are: \n%s", input);
		fflush(stdout);
		break;
	}		

	for(i=0; i<strlen(input); i++)
	{
		if(isalnum(input[i]))
		{
			chars++;
		}
		else if(isspace(input[i]))
		{
			words++;
		}
		if(input[i]=='\n')
		{	
			lines++;
		}
	}
	
	fp = fopen("stats.txt", "w+");
	fprintf(fp, "The statistics required are as follows:\n");
	fprintf(fp, "\nNumber of characters : %d", chars);
	fprintf(fp, "\nNumber of words : %d", words);
	fprintf(fp, "\nNumber of lines : %d", lines);
	
	rewind(fp);
	
	for(i=0; fgets(a, sizeof(a), fp)!=NULL; i++)
		strcat(output, a);	
	
	printf("\nCLIENT:\n%s", output);	
	write(fd2, output, strlen(output));	
	fclose(fp);
		
	return 0;
}

