//signal program:

#include <unistd.h>
#include <signal.h>
#include <sys/wait.h>
#include <stdio.h>

/* Handle SIGCHLD signals. */
void handle_sigchld(intsig){
	pid_t pid;
	int status;
//pid=wait(&status);
	while (1) {
		pid = waitpid(-1, &status, WNOHANG);
		if (pid <= 0) /* No more zombie children to reap. */
			break;

		printf("Reaped child %d\n",pid);
	}
sleep(1);
}

int main() {
	int i;
	signal(SIGCHLD,handle_sigchld);
	for (i= 0;i< 3;i++){
	if (fork() == 0) {
		/* Child-process code. */
		printf("Hello from child %d\n",getpid());
		sleep(5);
	return 0;
	/* Terminate child */
	}
}

/* Parent-process code. */
while (1)
	/* Wait for children */
	sleep(2);	
	/* to terminate. */
return 0;
} 



