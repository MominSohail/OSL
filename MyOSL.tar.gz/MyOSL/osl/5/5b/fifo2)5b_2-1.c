//Client code
#include <stdio.h>
#include <errno.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <sys/types.h>
#include <ctype.h>

int main()
{
	int fd1, fd2, num, i, no_lines=0, no_words=0, no_chars=0, c;
	char input[1000];
	char output[1000], a[100];
	FILE* fp = fopen("stats.txt", "w+");

	mkfifo("fifo1",0644);
	fd1=open("fifo1", O_RDONLY);
	
	mkfifo("fifo2",0644);
	fd2=open("fifo2", O_WRONLY);

	printf("\nReady to recieve from server\n");
	while((num=read(fd1,input,1000))>0)
	{
		input[num]='\0';
		printf("\nReceived from server (using FIFO 1): \n%s ", input);
		fflush(stdout);
		break;
	}
	
	for(i=0; i<strlen(input); i++)
	{
		if(isalnum(input[i]))
			no_chars++;
		else if(isspace(input[i]))
			no_words++;
		if(input[i] == '\n')
			no_lines++;
	}
	if(!isspace(input[strlen(input)]))
			no_words++;	
		
	fprintf(fp, "Number of characters: %d", no_chars);
	fprintf(fp, "\nNumber of words: %d", no_words);
	fprintf(fp, "\nNumber of lines: %d\n", no_lines+1);

	
	printf("\nSending the stats to the server (using FIFO 2)\n\n");
	
	rewind(fp);

	for (i=0; fgets(a, sizeof(a), fp)!=NULL; i++)
		strcat(output, a);
		
	write(fd2,output,strlen(output));							//write to FIFO
	write(fd1, "\n", 1);
	fclose(fp);
	return;
}


