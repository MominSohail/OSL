#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/types.h>
#include<pthread.h>
#include<semaphore.h>

sem_t lock[100];
sem_t room;
pthread_t pid[100];
void init(void)
{
	int i;
	for(i=0;i<5;i++)
		sem_init(&lock[i],0,1);
	sem_init(&room,0,4);

}

void* din(void* arg)
{
	int p=*(int*)arg;
	while(1)
	{
		sem_wait(&room);		
		printf("philosopher %d is hungry\n",p);
		sem_wait(&lock[p]);
		sem_wait(&lock[(p+1)%4]);
		printf("philosopher %d is eating\n",p);
		sleep(2);
		printf("philosopher %d is thinking\n",p);
		sem_post(&lock[(p+1)%4]);
		sem_post(&lock[p]);
		sem_post(&room);
		sleep(2);
	}
}

int main()
{
	int i;
	int c[]={0,1,2,3,4};
	init();
	for(i=0;i<5;i++)
	{
		pthread_create(&pid[i],NULL,din,&c[i]);
	}
	for(i=0;i<5;i++)
	{
		pthread_join(pid[i],NULL);
	}
return 0;
}
