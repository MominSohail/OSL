#include <linux/module.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

MODULE_INFO(vermagic, VERMAGIC_STRING);

__visible struct module __this_module
__attribute__((section(".gnu.linkonce.this_module"))) = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

static const struct modversion_info ____versions[]
__used
__attribute__((section("__versions"))) = {
	{ 0xb89a34a1, __VMLINUX_SYMBOL_STR(module_layout) },
	{ 0xaf1d5de9, __VMLINUX_SYMBOL_STR(single_release) },
	{ 0xdbf2c016, __VMLINUX_SYMBOL_STR(seq_read) },
	{ 0x28c350c8, __VMLINUX_SYMBOL_STR(seq_lseek) },
	{ 0x16f18734, __VMLINUX_SYMBOL_STR(remove_proc_entry) },
	{ 0x5cd9427c, __VMLINUX_SYMBOL_STR(proc_create_data) },
	{ 0x91831d70, __VMLINUX_SYMBOL_STR(seq_printf) },
	{ 0xba35ea3e, __VMLINUX_SYMBOL_STR(single_open) },
	{ 0xbdfb6dbb, __VMLINUX_SYMBOL_STR(__fentry__) },
};

static const char __module_depends[]
__used
__attribute__((section(".modinfo"))) =
"depends=";


MODULE_INFO(srcversion, "DB00AEEC058C56F702436AF");
