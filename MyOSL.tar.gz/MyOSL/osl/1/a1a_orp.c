#include<sys/types.h>
#include<unistd.h>
#include<stdio.h>
#include<sys/wait.h>
#include<stdlib.h>
#include<string.h>
void quicksort(int [],int ,int);
void partition(int[],int ,int);
void merge(int [],int ,int ,int);
int main()
{
	int pid,ppid,a[10],size,i;
	printf("\nParent :: My process id is :: %d",getpid());
	printf("Enter the size of array :: ");
	scanf("%d",&size);
	printf("Enter %d elements :: ",size );
	for(i=0;i<size;i++){
		scanf("%d",&a[i]);
	}
	
	//forking
	printf("\nForkingg");
	pid=fork();
	if(pid==0){
		//child process
		printf("\nChild :: My process id is :: %d",getpid());
		printf("\nChild :: My parent process pid is :: %d",getppid());
		quicksort(a,0,size-1);
		for(i=0;i<size;i++)
			printf("%d\t",a[i]);
		printf("\nChild :: I am dying now..\n");
		/*orphan*/
		printf("\nIm sleeping now..");
		sleep(10);
		system("ps -elf | grep a.out");
		
	}
	else if(pid>0){
		system("wait");		
		printf("\n Parent :: I am parent .. ");
		printf("\n My process pid is :: %d",getpid());
		partition(a,0,size-1);
		printf("\nThe sorted array :: parent ::\n ");
		for(i=0;i<size;i++)
			printf("%d\t",a[i]);
		/*Orphan*/
		system("ps -elf | grep a.out");
		exit(0);
	}
return 0;
}
void quicksort(int a[10],int first,int last)
{
	int pivot,i,j,temp;
	if(first<last){
		pivot=first;
		i=first;
		j=last;
		while(i<j){
			while(a[i]<=a[pivot]&&i<last)
			i++;
			while(a[j]>a[pivot])
			j--;
			
			if(i<j)		//swap a[i]and a[j]
			{
				temp=a[i];
				a[i]=a[j];
				a[j]=temp;
			}
		}
		//swap a[pivot] and a[j]
		temp=a[pivot];
		a[pivot]=a[j];
		a[j]=temp;
		quicksort(a,first,j-1);
		quicksort(a,j+1,last);
	}
}

void partition(int a[10],int low,int high)
{
	int mid;
	if(low<high){
		mid=(low+high)/2;
		partition(a,low,mid);
		partition(a,mid+1,high);
		merge(a,low,mid,high);
	}
}

void merge(int a[10],int low,int mid,int high)
{
	int i,m,k,l,temp[10];
	l=low;
	i=low;
	m=mid+1;
	while((l<=mid)&&(m<=high)){
		if(a[l]<=a[m]){
			temp[i]=a[l];
			l++;
		}
		else{
			temp[i]=a[m];
			m++;
		}
		i++;
	}
	if(l>mid){
		for(k=m;k<=high;k++){
			temp[i]=a[k];
			i++;
		}
	}
	else{
		for(k=l;k<=mid;k++){
			temp[i]=a[k];
			i++;
		}
	}
	for(k=low;k<=high;k++){
		a[k]=temp[k];
	}
}

