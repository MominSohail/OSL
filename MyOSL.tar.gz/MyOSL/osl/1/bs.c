#include <stdlib.h>
#include <stdio.h>
int binarySearch(int a[], int n, int min, int max)
{
    int i,mid;
    while(max >= min){
    
        mid = (min+max)/2;
        if(a[mid] == n)
            return mid;
        if(a[mid] < n)
            min = mid+1;
        else
            max = mid-1;
    }
    return -1;
}

int main(int argc,char *argv[]) {
	int i,j,r,result,arr[50];
	for(i=0;i<argc;i++){
		arr[i]=atoi(argv[i]);
	}
	printf("\nChild side\nArray :");
	for(j=0;j<argc;j++){
		printf("%d\t",arr[j]);
	}
	printf("\nEnter element to search :");
	scanf("%d",&r);

	result = binarySearch(arr,r,0,i-1);
	if(result == -1)
	    printf("\nElement Not Found!");
	else{
	    printf("\nElement found at location->%d",result+1);
	}
	return 0;
}

