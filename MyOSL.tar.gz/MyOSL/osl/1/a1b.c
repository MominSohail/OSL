#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <ctype.h>
void quicksort(int [10],int,int);
int main() {
	int a[10],n,pid,i,k;
	pid_t Parent_id, Child_id;
	char *argv[15],str[15];
	printf("Enter the no. of elements :");
	scanf("%d",&n);
	printf("Enter the elements :");
	for(i=0;i<n;i++){
		scanf("%d",&a[i]);
	}
	printf("Sorting in parent process :\n");
	quicksort(a,0,n-1);
	printf("\nArray :");
	for(i=0;i<n;i++){
		printf("%d\t",a[i]);
	}
	printf("\n");
    Parent_id = getpid();
    printf("\nIn parent process! ID->%d",Parent_id);

	pid=fork();
	if(pid==0){
	        Child_id = getpid();
   	    	Parent_id = getppid();
	
	printf("\nIn child process! ID->%d\nMy parent id :: %d",Child_id,Parent_id);
		for(k=0;k<n;++k){
			sprintf(str,"%d",a[k]);
			argv[k] =(char*)malloc(sizeof(str));
			strcpy(argv[k],str);
		}
		argv[k]=NULL;
		execv("./bs",argv);
		printf("execv failed");
	}
	else {
		sleep(10);
		wait();
		printf("\nIn parent\n");
	}

	return 0;
}

void quicksort(int x[10],int first,int last)
{
	int pivot,j,temp,i;
	if(first<last)
	{
		pivot=first;
		i=first;
		j=last;
		while(i<j)
		{
			while(x[i]<=x[pivot]&&i<last)
				i++;
			while(x[j]>x[pivot])
				j--;
			if(i<j)
			{
				temp=x[i];
				x[i]=x[j];
				x[j]=temp;
			}
		}
		temp=x[pivot];
		x[pivot]=x[j];
		x[j]=temp;
		quicksort(x,first,j-1);
		quicksort(x,j+1,last);
	}
}

