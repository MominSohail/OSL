#include <stdio.h>
#include <linux/kernel.h>
#include <sys/syscall.h>
#include <unistd.h>

int main()
{
	long int r = syscall(358);					//Your syscall number to be put in place of 358
	printf("My own System call sys_hello returned %ld\n",r);			//should return 0 and not -1
	return 0;
}
