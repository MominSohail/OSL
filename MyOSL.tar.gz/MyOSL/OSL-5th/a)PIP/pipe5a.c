#include <sys/types.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void read_from_pipe1 (int file);
void read_from_pipe2 (int file);
void write_to_pipe1 (int file);
void write_to_pipe2 (int file, FILE* fp);

int main (void)
{
	pid_t pid;
	int mypipe[2], pipe2[2];
	
	FILE *fp;

	if (pipe (mypipe))// two descriptor at mypipe[0] to read mypipe[1] to write 	//Pipe returns -1 on failure
	{
		fprintf (stderr, "Pipe failed.\n");
		return EXIT_FAILURE;
	}
	if (pipe (pipe2))							//Pipe returns -1 on failure
	{
		fprintf (stderr, "Pipe failed.\n");
		return EXIT_FAILURE;
	}

	pid = fork ();
	if (pid == (pid_t) 0)						//This is the child process.
	{
		 close (mypipe[1]);
		 printf("Child process reading from pipe 1\n");
		 read_from_pipe1 (mypipe[0]);

		close (pipe2[0]);
		printf("Child process writing to pipe 2\n");
		write_to_pipe2 (pipe2[1], fp);
		return EXIT_SUCCESS;
	}
	else										//This is the parent process.
    {
       close (mypipe[0]);
	printf("Parent process writing to pipe 1\n");
       write_to_pipe1 (mypipe[1]);
	wait();
       close (pipe2[1]);
	printf("Parent process reading from pipe 2\n");
       read_from_pipe2 (pipe2[0]);
       return EXIT_SUCCESS;
    }

    return 0;
}

void read_from_pipe1 (int file)				// Read filename from the pipe and open the file
{
	FILE *stream;
	       int c;
	       stream = fdopen (file, "r");
	       while ((c = fgetc (stream)) != EOF)
	         putchar (c);
	       fclose (stream);
}

void write_to_pipe1 (int file)					// Write path of the file to the pipe 1
{
	FILE *stream;
	stream = fdopen (file, "w");

	
        fprintf (stream, "\nhello, PIP1!\n");
       fprintf (stream, "Written by Parent to pip1\n");
	fclose (stream);
}

void read_from_pipe2 (int file)					// Read from the pipe and print to terminal
{
	FILE *stream;
	       int c;
	       stream = fdopen (file, "r");
	       while ((c = fgetc (stream)) != EOF)
	         putchar (c);
	       fclose (stream);
}

void write_to_pipe2 (int file, FILE* fp)		// Write text from testfile to the pipe.
{
	FILE *stream;
	stream = fdopen (file, "w");

	
        fprintf (stream, "\nhello, PIP2!\n");
       fprintf (stream, "Written by child to pip2\n");
	fclose (stream);
}


