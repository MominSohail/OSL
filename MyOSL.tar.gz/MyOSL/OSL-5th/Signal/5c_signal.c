#include<stdio.h>
#include<stdlib.h>
#include<signal.h>

void sigchld_handle()
{
	int status, id;
	
	while(1)
	{
		sleep(1);
		//id = waitpid(-1, &status, 1);
id = waitpid(-1, &status, WNOHANG);
		if(id <= 0)
			break;
		printf("\nChild reaped - PID %d", id);
	}
	printf("\n");
}

int main()
{
	int i, n, pid;

	signal(SIGCHLD, sigchld_handle);
	printf("\nEnter the number of children to produce and reap: ");
	scanf("%d", &n);

	for(i=0; i<n; i++)
	{
		sleep(1);
		pid = fork();
		if(pid == 0)
		{
			printf("Child process with id %d produced", getpid());	
			printf("\n");			
			sleep(1);
	
			return 0;
		}
	}

	sleep(10);	
		
	return 0;
}
