//Server code
#include <stdio.h>
#include <errno.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <sys/types.h>

int main (void)
{
	int i=0, fd1, fd2, num;
	char input[1000], output[1000], c;				//buffer for input sentences
	
	mkfifo("fifo1",0777);						//create FIFO 1	
	fd1=open("fifo1",O_WRONLY);					//O_WRONLY - Open in write only mode 

	mkfifo("fifo2",0777);						//create FIFO 2				
	fd2=open("fifo2",O_RDONLY);					//O_WRONLY - Open in read only mode 

    printf("\nReady to broadcast to client\n");
	printf("Enter message : \n");
	while((c=getc(stdin))!='`')					//recieve sentences from user until ` is pressed
		input[i++] = c;
	input[i]='\0';			
	write(fd1, input, strlen(input));						//write to FIFO
		
	while((num=read(fd2,output,1000))>0)
	{
		output[num]='\0';
		printf("\nStats recieved from client: \n%s", output);
		fflush(stdout);
		break;
	}
    return;
}


