#include <sys/types.h> 
#include <sys/wait.h> 
#include <stdio.h>    
#include <stdlib.h>    
#include <unistd.h>  

void main()
{
	int pid, ppid;

	printf("\nPARENT: My process-id is %d.", getpid());
	printf("\nForking now!\n");

	pid = fork();					
	if(pid==0){
		printf("\nCHILD: My process-id is %d.", getpid());
		printf("\nCHILD: My parent's process-id is %d.", getppid());
		printf("\nCHILD: I am dying now");
		printf("\n-------------------------------------------------------\n\n");
                
		system("ps -elf | grep a.out");
                 exit(0);
	}
	else if (pid>0){
		printf("\nPARENT: I am back. ");
		printf("\nPARENT: My process-id is %d.", getpid());	
		printf("\nPARENT: My child's process-id is %d.", pid);
		printf("\nPARENT: I am sleeping now.");
		sleep(10);
		printf("\n-------------------------------------------------------\n");
		system("ps -elf | grep a.out");
	}
}


