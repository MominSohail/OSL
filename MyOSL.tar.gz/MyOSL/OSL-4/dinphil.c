#include <stdio.h>
#include <unistd.h>
#include <pthread.h>
#include <semaphore.h>
#define M 10

struct Philosopher
{
	char state;
	sem_t sem;
	pthread_mutex_t flag;
}chop[M];
int no;
void initalize(int i){
	int j;
	for(j=0;j<i;j++){
		chop[j].state ='T';
		sem_init(&chop[j].sem,0,0);
		pthread_mutex_init(&chop[j].flag,NULL);
	}
}
void test(int pnum){
	if(chop[pnum].state == 'H' && chop[(pnum+no-1)%no].state !='E' && chop[(pnum+1)%no].state!='E')
         {
		chop[pnum].state = 'E';
		printf("\nPhilosopher %d takes fork from %d and %d\n",pnum,(pnum+no-1)%no,(pnum+1)%no );
		printf("\nPhilosopher %d is Eating\n", pnum);
		sem_post(&chop[pnum].sem);
	}
}	
/*void think(int pnum){
	printf("\nPhilosopher %d is thinking.\n", pnum+1);
}*/
void take_fork(int pnum){
	pthread_mutex_lock(&chop[pnum].flag);
	chop[pnum].state = 'H';
	printf("\nPhilosopher %d is Hungry.\n",pnum);
	test(pnum);
	pthread_mutex_unlock(&chop[pnum].flag);
	sem_wait(&chop[pnum].sem);
	//sleep(1);
}

void put_fork(int pnum){
	pthread_mutex_lock(&chop[pnum].flag);
	chop[pnum].state = 'T';
	printf("\nPhilosopher %d puts fork\n",pnum);
	test((pnum+no-1)%no);
	test((pnum+1)%no);
	pthread_mutex_unlock(&chop[pnum].flag);
}
void* check(void *t){
	while(1){
	//	think(pnum);
		int pnum = *((int *)t);
		sleep(2);
		take_fork(pnum);
		sleep(2);
		put_fork(pnum);
	}
}
int main(){
	int i,p[M];
	pthread_t pt[M];
	printf("\nEnter no of Philosophers : :\n");
	scanf("%d",&no);
	for(i=0;i<no;i++){
		p[i] = i;
	}
	for(i=0;i<no;i++){
		printf("\nPhilosopher %d is thinking.\n",p[i]);
		pthread_create(&pt[i],NULL,check,&p[i]);
	}
	for(i=0;i<no;i++){
		pthread_join(pt[i],NULL);
	}
	return 0;
}
