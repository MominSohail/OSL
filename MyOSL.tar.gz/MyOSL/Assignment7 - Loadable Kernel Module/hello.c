#include<linux/kernel.h>
#include<linux/module.h>
#include<linux/init.h>

MODULE_AUTHOR("Amar Chandole");
MODULE_DESCRIPTION("A simple hello world module");

static int __init hello_begins(void)
{
	printk(KERN_WARNING "Hello :/\n");
	return 0;
}

static void __exit hello_ends(void)
{
	printk(KERN_WARNING "Bye :/\n");
}

module_init(hello_begins);
module_exit(hello_ends);


